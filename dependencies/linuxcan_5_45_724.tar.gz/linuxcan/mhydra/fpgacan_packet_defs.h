/*
**             Copyright 2023 by Kvaser AB, Molndal, Sweden
**                         http://www.kvaser.com
**
** This software is dual licensed under the following two licenses:
** BSD-new and GPLv2. You may use either one. See the included
** COPYING file for details.
**
** License: BSD-new
** ==============================================================================
** Redistribution and use in source and binary forms, with or without
** modification, are permitted provided that the following conditions are met:
**     * Redistributions of source code must retain the above copyright
**       notice, this list of conditions and the following disclaimer.
**     * Redistributions in binary form must reproduce the above copyright
**       notice, this list of conditions and the following disclaimer in the
**       documentation and/or other materials provided with the distribution.
**     * Neither the name of the <organization> nor the
**       names of its contributors may be used to endorse or promote products
**       derived from this software without specific prior written permission.
**
** THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
** AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
** IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
** ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
** LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
** CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
** SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR
** BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER
** IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
** ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
** POSSIBILITY OF SUCH DAMAGE.
**
**
** License: GPLv2
** ==============================================================================
** This program is free software; you can redistribute it and/or modify
** it under the terms of the GNU General Public License as published by
** the Free Software Foundation; either version 2 of the License, or
** (at your option) any later version.
**
** This program is distributed in the hope that it will be useful,
** but WITHOUT ANY WARRANTY; without even the implied warranty of
** MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
** GNU General Public License for more details.
**
** You should have received a copy of the GNU General Public License
** along with this program; if not, write to the Free Software
** Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA
**
**
** IMPORTANT NOTICE:
** ==============================================================================
** This source code is made available for free, as an open license, by Kvaser AB,
** for use with its applications. Kvaser AB does not accept any liability
** whatsoever for any third party patent or other immaterial property rights
** violations that may result from any usage of this source code, regardless of
** the combination of source code and various applications that it can be used
** in, or with.
**
** -----------------------------------------------------------------------------
*/

#ifndef __FPGA_CAN_PACKET_DEFS_H__
#define __FPGA_CAN_PACKET_DEFS_H__

/*****************************************************************************/
/* Bitwise operations, should be same as those in bits.h in minihydra:       */

#define _ones(nbits)                 ((1UL << (nbits)) - 1)
#define _mask(nbits, lshift)         (_ones(nbits) << lshift)
#define _get(nbits, lshift, value)   (((value) >> (lshift)) & _ones(nbits))
#define _field(nbits, lshift, value) (((value) << (lshift)) & _mask(nbits, lshift))

#define ones(field)         _ones(field##_NBITS)
#define mask(field)         _mask(field##_NBITS, field##_LSHIFT)
#define get(field, value)   _get(field##_NBITS, field##_LSHIFT, value)
#define field(field, value) _field(field##_NBITS, field##_LSHIFT, value)

/*****************************************************************************/
/* Packet definitions, should be same as those in fpgacan_packet_defs.h in   */
/* minihydra:                                                                */

// +----------------------------------------------------------------------------
// | Received and transmitted Packets (RTPACKET)
// | Received Packets (RPACKET)
// | Transmitted Packets (TPACKET)
// +----------------------------------------------------------------------------

// Id Field (W0)
#define RTPACKET_SRR_LSHIFT     31
#define RTPACKET_SRR_NBITS      1
#define RTPACKET_SRR_MSK        mask(RTPACKET_SRR)
#define RTPACKET_SRR_GET(value) get(RTPACKET_SRR, value)
#define RTPACKET_SRR(value)     field(RTPACKET_SRR, value)

#define RTPACKET_IDE_LSHIFT     30
#define RTPACKET_IDE_NBITS      1
#define RTPACKET_IDE_MSK        mask(RTPACKET_IDE)
#define RTPACKET_IDE_GET(value) get(RTPACKET_IDE, value)
#define RTPACKET_IDE(value)     field(RTPACKET_IDE, value)

#define RTPACKET_RTR_LSHIFT     29
#define RTPACKET_RTR_NBITS      1
#define RTPACKET_RTR_MSK        mask(RTPACKET_RTR)
#define RTPACKET_RTR_GET(value) get(RTPACKET_RTR, value)
#define RTPACKET_RTR(value)     field(RTPACKET_RTR, value)

#define RTPACKET_ID_LSHIFT     0
#define RTPACKET_ID_NBITS      29
#define RTPACKET_ID_MSK        mask(RTPACKET_ID)
#define RTPACKET_ID_GET(value) get(RTPACKET_ID, value)
#define RTPACKET_ID(value)     field(RTPACKET_ID, value)

// Control field
// Control field (W1)
#define TPACKET_AREQ_LSHIFT     31
#define TPACKET_AREQ_NBITS      1
#define TPACKET_AREQ_MSK        mask(TPACKET_AREQ)
#define TPACKET_AREQ_GET(value) get(TPACKET_AREQ, value)
#define TPACKET_AREQ(value)     field(TPACKET_AREQ, value)

#define TPACKET_TREQ_LSHIFT     30
#define TPACKET_TREQ_NBITS      1
#define TPACKET_TREQ_MSK        mask(TPACKET_TREQ)
#define TPACKET_TREQ_GET(value) get(TPACKET_TREQ, value)
#define TPACKET_TREQ(value)     field(TPACKET_TREQ, value)

#define TPACKET_SSM_LSHIFT     16
#define TPACKET_SSM_NBITS      1
#define TPACKET_SSM_MSK        mask(TPACKET_SSM)
#define TPACKET_SSM_GET(value) get(TPACKET_SSM, value)
#define TPACKET_SSM(value)     field(TPACKET_SSM, value)

#define RPACKET_PTYPE_LSHIFT     28
#define RPACKET_PTYPE_NBITS      4
#define RPACKET_PTYPE_MSK        mask(RPACKET_PTYPE)
#define RPACKET_PTYPE_GET(value) get(RPACKET_PTYPE, value)

#define RPACKET_PTYPE_DATA       0
#define RPACKET_PTYPE_ACK        1
#define RPACKET_PTYPE_TXRQ       2
#define RPACKET_PTYPE_ERROR      3
#define RPACKET_PTYPE_EFLUSH_ACK 4
#define RPACKET_PTYPE_EFRAME_ACK 5
#define RPACKET_PTYPE_STATUS     8
#define RPACKET_PTYPE_BUS_LOAD   9
#define RPACKET_PTYPE_OFFSET     10
#define RPACKET_PTYPE_GLITCH     11
#define RPACKET_PTYPE_DIAG       12
#define RPACKET_PTYPE_DELAY      13

#define RPACKET_CHID_LSHIFT     25
#define RPACKET_CHID_NBITS      3
#define RPACKET_CHID_MSK        mask(RPACKET_CHID)
#define RPACKET_CHID_GET(value) get(RPACKET_CHID, value)
#define RPACKET_CHID(value)     field(RPACKET_CHID, value)

#define RPACKET_EPLR_LSHIFT     24
#define RPACKET_EPLR_NBITS      1
#define RPACKET_EPLR_MSK        mask(RPACKET_EPLR)
#define RPACKET_EPLR_GET(value) get(RPACKET_EPLR, value)

#define RPACKET_EWLR_LSHIFT     23
#define RPACKET_EWLR_NBITS      1
#define RPACKET_EWLR_MSK        mask(RPACKET_EWLR)
#define RPACKET_EWLR_GET(value) get(RPACKET_EWLR, value)

#define RPACKET_ROVF_LSHIFT     22
#define RPACKET_ROVF_NBITS      1
#define RPACKET_ROVF_MSK        mask(RPACKET_ROVF)
#define RPACKET_ROVF_GET(value) get(RPACKET_ROVF, value)

#define RTPACKET_FDF_LSHIFT     15
#define RTPACKET_FDF_NBITS      1
#define RTPACKET_FDF_MSK        mask(RTPACKET_FDF)
#define RTPACKET_FDF_GET(value) get(RTPACKET_FDF, value)
#define RTPACKET_FDF(value)     field(RTPACKET_FDF, value)

#define RTPACKET_BRS_LSHIFT     14
#define RTPACKET_BRS_NBITS      1
#define RTPACKET_BRS_MSK        mask(RTPACKET_BRS)
#define RTPACKET_BRS_GET(value) get(RTPACKET_BRS, value)
#define RTPACKET_BRS(value)     field(RTPACKET_BRS, value)

#define RTPACKET_ESI_LSHIFT     13
#define RTPACKET_ESI_NBITS      1
#define RTPACKET_MSK_ESI        mask(RTPACKET_ESI)
#define RTPACKET_ESI_GET(value) get(RTPACKET_ESI, value)

#define RTPACKET_EHSF_LSHIFT     12
#define RTPACKET_EHSF_NBITS      1
#define RTPACKET_EHSF_MSK        mask(RTPACKET_EHSF)
#define RTPACKET_EHSF_GET(value) get(RTPACKET_EHSF, value)
#define RTPACKET_EHSF(value)     field(RTPACKET_EHSF, value)

#define RTPACKET_DLC_LSHIFT     8
#define RTPACKET_DLC_NBITS      4
#define RTPACKET_DLC_MSK        mask(RTPACKET_DLC)
#define RTPACKET_DLC_GET(value) get(RTPACKET_DLC, value)
#define RTPACKET_DLC(value)     field(RTPACKET_DLC, value)

#define RTPACKET_SEQ_LSHIFT     0
#define RTPACKET_SEQ_NBITS      8
#define RTPACKET_SEQ_MSK        mask(RTPACKET_SEQ)
#define RTPACKET_SEQ_GET(value) get(RTPACKET_SEQ, value)
#define RTPACKET_SEQ(value)     field(RTPACKET_SEQ, value)

// Offset
#define OPACKET_NBITS_LSHIFT     16
#define OPACKET_NBITS_NBITS      10
#define OPACKET_NBITS_MSK        mask(OPACKET_NBITS)
#define OPACKET_NBITS_GET(value) get(OPACKET_NBITS, value)

#define OPACKET_OFFSET_LSHIFT     0
#define OPACKET_OFFSET_NBITS      13
#define OPACKET_OFFSET_MSK        mask(OPACKET_OFFSET)
#define OPACKET_OFFSET_GET(value) get(OPACKET_OFFSET, value)

// Bus Load
#define BPACKET_BUS_LOAD_LSHIFT     0
#define BPACKET_BUS_LOAD_NBITS      20
#define BPACKET_BUS_LOAD_MSK        mask(BPACKET_BUS_LOAD)
#define BPACKET_BUS_LOAD_GET(value) get(BPACKET_BUS_LOAD, value)

// TXACK/TXRQ
#define APACKET_SEQ_LSHIFT     0
#define APACKET_SEQ_NBITS      8
#define APACKET_SEQ_MSK        mask(APACKET_SEQ)
#define APACKET_SEQ_GET(value) get(APACKET_SEQ, value)

#define APACKET_FLUSHED_LSHIFT     8
#define APACKET_FLUSHED_NBITS      1
#define APACKET_FLUSHED_MSK        mask(APACKET_FLUSHED)
#define APACKET_FLUSHED_GET(value) get(APACKET_FLUSHED, value)

// single shot Not sent
#define APACKET_NACK_LSHIFT     10
#define APACKET_NACK_NBITS      1
#define APACKET_NACK_MSK        mask(APACKET_NACK)
#define APACKET_NACK_GET(value) get(APACKET_NACK, value)

// arbitration lost
#define APACKET_ABL_LSHIFT     11
#define APACKET_ABL_NBITS      1
#define APACKET_ABL_MSK        mask(APACKET_ABL)
#define APACKET_ABL_GET(value) get(APACKET_ABL, value)

#define APACKET_CONTROL_ACK_LSHIFT     9
#define APACKET_CONTROL_ACK_NBITS      1
#define APACKET_CONTROL_ACK_MSK        mask(APACKET_CONTROL_ACK)
#define APACKET_CONTROL_ACK_GET(value) get(APACKET_CONTROL_ACK, value)

// Error packet
#define EPACKET_EPLR_LSHIFT     24
#define EPACKET_EPLR_NBITS      1
#define EPACKET_EPLR_MSK        mask(EPACKET_EPLR)
#define EPACKET_EPLR_GET(value) get(EPACKET_EPLR, value)

#define EPACKET_EWLR_LSHIFT     23
#define EPACKET_EWLR_NBITS      1
#define EPACKET_EWLR_MSK        mask(EPACKET_EWLR)
#define EPACKET_EWLR_GET(value) get(EPACKET_EWLR, value)

#define EPACKET_ROVF_LSHIFT     22
#define EPACKET_ROVF_NBITS      1
#define EPACKET_ROVF_MSK        mask(EPACKET_ROVF)
#define EPACKET_ROVF_GET(value) get(EPACKET_ROVF, value)

#define EPACKET_BOFF_LSHIFT     16
#define EPACKET_BOFF_NBITS      1
#define EPACKET_BOFF_MSK        mask(EPACKET_BOFF)
#define EPACKET_BOFF_GET(value) get(EPACKET_BOFF, value)

#define EPACKET_TXE_LSHIFT     0
#define EPACKET_TXE_NBITS      8
#define EPACKET_TXE_MSK        mask(EPACKET_TXE)
#define EPACKET_TXE_GET(value) get(EPACKET_TXE, value)

#define EPACKET_RXE_LSHIFT     8
#define EPACKET_RXE_NBITS      8
#define EPACKET_RXE_MSK        mask(EPACKET_RXE)
#define EPACKET_RXE_GET(value) get(EPACKET_RXE, value)

#define EPACKET_TYPE_LSHIFT     10
#define EPACKET_TYPE_NBITS      3
#define EPACKET_TYPE_MSK        mask(EPACKET_TYPE)
#define EPACKET_TYPE_GET(value) get(EPACKET_TYPE, value)

#define EPACKET_SEG_LSHIFT     6
#define EPACKET_SEG_NBITS      4
#define EPACKET_SEG_MSK        mask(EPACKET_SEG)
#define EPACKET_SEG_GET(value) get(EPACKET_SEG, value)

#define EPACKET_SEG2_LSHIFT     1
#define EPACKET_SEG2_NBITS      5
#define EPACKET_SEG2_MSK        mask(EPACKET_SEG2)
#define EPACKET_SEG2_GET(value) get(EPACKET_SEG2, value)

#define EPACKET_DIR_LSHIFT     0
#define EPACKET_DIR_NBITS      1
#define EPACKET_DIR_MSK        mask(EPACKET_DIR)
#define EPACKET_DIR_GET(value) get(EPACKET_DIR, value)

typedef enum {
    ESEG_EXT_ID,
    ESEG_CRC_SEQ,
    ESEG_BASE_ID,
    ESEG_DLC,
    ESEG_EOF,
    ESEG_OVERLOAD,
    ESEG_ACTIVE_ERROR,
    ESEG_PASSIVE_ERROR,
    ESEG_ERROR_DELIM,
    ESEG_IM,
    ESEG_OTHER // Not bit count field
} eseg_t;

typedef enum {
    ESEG_SOF,
    ESEG_SRR_RTR,
    ESEG_IDE,
    ESEG_RTR,
    ESEG_R0,
    ESEG_FD_R0,
    ESEG_R1,
    ESEG_BRS,
    ESEG_ESI,
    ESEG_DATA,
    ESEG_CRC_DELIM,
    ESEG_ACK_SLOT,
    ESEG_ACK_DELIM,
    ESEG_BUG
} eseg2_t;

typedef enum { E_OK, E_BIT, E_BIT_SSP, E_STUFF_ARB, E_STUFF, E_FORM, E_ACK, E_CRC } etype_t;

enum { DLC12 = 9, DLC16 = 10, DLC20 = 11, DLC24 = 12, DLC32 = 13, DLC48 = 14, DLC64 = 15 };

// Status packet
#define SPACKET_EPLR_LSHIFT     24
#define SPACKET_EPLR_NBITS      1
#define SPACKET_EPLR_MSK        mask(SPACKET_EPLR)
#define SPACKET_EPLR_GET(value) get(SPACKET_EPLR, value)

#define SPACKET_EWLR_LSHIFT     23
#define SPACKET_EWLR_NBITS      1
#define SPACKET_EWLR_MSK        mask(SPACKET_EWLR)
#define SPACKET_EWLR_GET(value) get(SPACKET_EWLR, value)

#define SPACKET_ROVF_LSHIFT     22
#define SPACKET_ROVF_NBITS      1
#define SPACKET_ROVF_MSK        mask(SPACKET_ROVF)
#define SPACKET_ROVF_GET(value) get(SPACKET_ROVF, value)

#define SPACKET_RMCD_LSHIFT     22
#define SPACKET_RMCD_NBITS      1
#define SPACKET_RMCD_MSK        mask(SPACKET_RMCD)
#define SPACKET_RMCD_GET(value) get(SPACKET_RMCD, value)

#define SPACKET_AUTO_LSHIFT     21
#define SPACKET_AUTO_NBITS      1
#define SPACKET_AUTO_MSK        mask(SPACKET_AUTO)
#define SPACKET_AUTO_GET(value) get(SPACKET_AUTO, value)

#define SPACKET_IRM_LSHIFT     21
#define SPACKET_IRM_NBITS      1
#define SPACKET_IRM_MSK        mask(SPACKET_IRM)
#define SPACKET_IRM_GET(value) get(SPACKET_IRM, value)

#define SPACKET_IDET_LSHIFT     20
#define SPACKET_IDET_NBITS      1
#define SPACKET_IDET_MSK        mask(SPACKET_IDET)
#define SPACKET_IDET_GET(value) get(SPACKET_IDET, value)

#define SPACKET_BOFF_LSHIFT     16
#define SPACKET_BOFF_NBITS      1
#define SPACKET_BOFF_MSK        mask(SPACKET_BOFF)
#define SPACKET_BOFF_GET(value) get(SPACKET_BOFF, value)

#define SPACKET_RXERR_LSHIFT     8
#define SPACKET_RXERR_NBITS      8
#define SPACKET_RXERR_MSK        mask(SPACKET_RXERR)
#define SPACKET_RXERR_GET(value) get(SPACKET_RXERR, value)

#define SPACKET_TXERR_LSHIFT     0
#define SPACKET_TXERR_NBITS      8
#define SPACKET_TXERR_MSK        mask(SPACKET_TXERR)
#define SPACKET_TXERR_GET(value) get(SPACKET_TXERR, value)

#define SPACKET_CMD_SEQ_LSHIFT     0
#define SPACKET_CMD_SEQ_NBITS      8
#define SPACKET_CMD_SEQ_MSK        mask(SPACKET_CMD_SEQ)
#define SPACKET_CMD_SEQ_GET(value) get(SPACKET_CMD_SEQ, value)

// +----------------------------------------------------------------------------
// | Transmitted Packets
// |
// +----------------------------------------------------------------------------
#define TPACKET_PTYPE_EGEN        0
#define TPACKET_PTYPE_TOG         1
#define TPACKET_PTYPE_GGEN        2
#define TPACKET_PTYPE_OVERLOAD    3
#define TPACKET_PTYPE_END_FLUSH   4
#define TPACKET_PTYPE_ERROR_FRAME 5

#define TPACKET_CONTROL_PTYPE_LSHIFT     29
#define TPACKET_CONTROL_PTYPE_NBITS      3
#define TPACKET_CONTROL_PTYPE_MSK        mask(TPACKET_CONTROL_PTYPE)
#define TPACKET_CONTROL_PTYPE_GET(value) get(TPACKET_CONTROL_PTYPE, value)
#define TPACKET_CONTROL_PTYPE(value)     field(TPACKET_CONTROL_PTYPE, value)

#define FPGA_CAN_CONTROL_END_FLUSH   TPACKET_CONTROL_PTYPE(TPACKET_PTYPE_END_FLUSH)
#define FPGA_CAN_CONTROL_ERROR_FRAME TPACKET_CONTROL_PTYPE(TPACKET_PTYPE_ERROR_FRAME)

#define FPGA_CAN_DIAG_COUNT_LSHIFT     16
#define FPGA_CAN_DIAG_COUNT_NBITS      8
#define FPGA_CAN_DIAG_COUNT_MSK        mask(FPGA_CAN_DIAG_COUNT)
#define FPGA_CAN_DIAG_COUNT_GET(value) get(FPGA_CAN_DIAG_COUNT, value)
#define FPGA_CAN_DIAG_COUNT(value)     field(FPGA_CAN_DIAG_COUNT, value)

#define FPGA_CAN_DIAG_EPL_LSHIFT     0
#define FPGA_CAN_DIAG_EPL_NBITS      1
#define FPGA_CAN_DIAG_EPL_MSK        mask(FPGA_CAN_DIAG_EPL)
#define FPGA_CAN_DIAG_EPL_GET(value) get(FPGA_CAN_DIAG_EPL, value)
#define FPGA_CAN_DIAG_EPL(value)     field(FPGA_CAN_DIAG_EPL, value)

#define FPGA_CAN_DIAG_EWL_LSHIFT     31
#define FPGA_CAN_DIAG_EWL_NBITS      1
#define FPGA_CAN_DIAG_EWL_MSK        mask(FPGA_CAN_DIAG_EWL)
#define FPGA_CAN_DIAG_EWL_GET(value) get(FPGA_CAN_DIAG_EWL, value)
#define FPGA_CAN_DIAG_EWL(value)     field(FPGA_CAN_DIAG_EWL, value)

#define FPGA_CAN_DIAG_RXE_LSHIFT     23
#define FPGA_CAN_DIAG_RXE_NBITS      8
#define FPGA_CAN_DIAG_RXE_MSK        mask(FPGA_CAN_DIAG_RXE)
#define FPGA_CAN_DIAG_RXE_GET(value) get(FPGA_CAN_DIAG_RXE, value)
#define FPGA_CAN_DIAG_RXE(value)     field(FPGA_CAN_DIAG_RXE, value)

#define FPGA_CAN_DIAG_TXE_LSHIFT     15
#define FPGA_CAN_DIAG_TXE_NBITS      8
#define FPGA_CAN_DIAG_TXE_MSK        mask(FPGA_CAN_DIAG_TXE)
#define FPGA_CAN_DIAG_TXE_GET(value) get(FPGA_CAN_DIAG_TXE, value)
#define FPGA_CAN_DIAG_TXE(value)     field(FPGA_CAN_DIAG_TXE, value)

#define FPGA_CAN_DIAG_TSEG1_LSHIFT     9
#define FPGA_CAN_DIAG_TSEG1_NBITS      6
#define FPGA_CAN_DIAG_TSEG1_MSK        mask(FPGA_CAN_DIAG_TSEG1)
#define FPGA_CAN_DIAG_TSEG1_GET(value) get(FPGA_CAN_DIAG_TSEG1, value)
#define FPGA_CAN_DIAG_TSEG1(value)     field(FPGA_CAN_DIAG_TSEG1, value)

#define FPGA_CAN_DIAG_TSEG2_LSHIFT     4
#define FPGA_CAN_DIAG_TSEG2_NBITS      5
#define FPGA_CAN_DIAG_TSEG2_MSK        mask(FPGA_CAN_DIAG_TSEG2)
#define FPGA_CAN_DIAG_TSEG2_GET(value) get(FPGA_CAN_DIAG_TSEG2, value)
#define FPGA_CAN_DIAG_TSEG2(value)     field(FPGA_CAN_DIAG_TSEG2, value)

#define FPGA_CAN_DIAG_SJW_LSHIFT     0
#define FPGA_CAN_DIAG_SJW_NBITS      4
#define FPGA_CAN_DIAG_SJW_MSK        mask(FPGA_CAN_DIAG_SJW)
#define FPGA_CAN_DIAG_SJW_GET(value) get(FPGA_CAN_DIAG_SJW, value)
#define FPGA_CAN_DIAG_SJW(value)     field(FPGA_CAN_DIAG_SJW, value)

#define FPGA_CAN_DELAY_LSHIFT     0
#define FPGA_CAN_DELAY_NBITS      8
#define FPGA_CAN_DELAY_MSK        mask(FPGA_CAN_DELAY)
#define FPGA_CAN_DELAY_GET(value) get(FPGA_CAN_DELAY, value)
#define FPGA_CAN_DELAY(value)     field(FPGA_CAN_DELAY, value)

#define FPGA_CAN_DELAY_HS_START_LSHIFT     8
#define FPGA_CAN_DELAY_HS_START_NBITS      3
#define FPGA_CAN_DELAY_HS_START_MSK        mask(FPGA_CAN_DELAY_HS_START)
#define FPGA_CAN_DELAY_HS_START_GET(value) get(FPGA_CAN_DELAY_HS_START, value)
#define FPGA_CAN_DELAY_HS_START(value)     field(FPGA_CAN_DELAY_HS_START, value)

#define FPGA_CAN_DELAY_HS_STOP_LSHIFT     16
#define FPGA_CAN_DELAY_HS_STOP_NBITS      3
#define FPGA_CAN_DELAY_HS_STOP_MSK        mask(FPGA_CAN_DELAY_HS_STOP)
#define FPGA_CAN_DELAY_HS_STOP_GET(value) get(FPGA_CAN_DELAY_HS_STOP, value)
#define FPGA_CAN_DELAY_HS_STOP(value)     field(FPGA_CAN_DELAY_HS_STOP, value)

#define FPGA_CAN_DELAY_LSHIFT     0
#define FPGA_CAN_DELAY_NBITS      8
#define FPGA_CAN_DELAY_MSK        mask(FPGA_CAN_DELAY)
#define FPGA_CAN_DELAY_GET(value) get(FPGA_CAN_DELAY, value)
#define FPGA_CAN_DELAY(value)     field(FPGA_CAN_DELAY, value)

#endif
